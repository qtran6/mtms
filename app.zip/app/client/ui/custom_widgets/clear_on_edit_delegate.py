from PySide6.QtWidgets import QStyledItemDelegate


class ClearOnEditDelegate(QStyledItemDelegate):
    """When the user starts editing a cell, the editor opens empty
    instead of showing the current value."""

    def setEditorData(self, editor, index):
        # Default would call editor.setText(index.data())
        # Skipping that leaves the editor empty
        pass